from bot.trading import TradingBot

if __name__ == "__main__":
    bot = TradingBot()
    bot.run()
