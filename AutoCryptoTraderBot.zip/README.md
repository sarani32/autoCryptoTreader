# AutoCryptoTraderBot
A smart auto-trading bot for crypto (Binance & TheTrueTrade).
